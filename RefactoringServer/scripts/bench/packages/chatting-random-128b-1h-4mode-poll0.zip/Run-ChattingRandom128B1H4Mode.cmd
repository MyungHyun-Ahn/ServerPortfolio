@echo off
setlocal
call "%~dp0scripts\bench\packages\chatting-random-128b-1h-4mode-poll0\Run.cmd" %*
endlocal

