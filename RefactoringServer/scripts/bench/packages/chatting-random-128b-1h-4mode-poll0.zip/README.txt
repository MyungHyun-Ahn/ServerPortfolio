﻿Self-contained benchmark package

1. Extract this zip to any folder.
2. Run Run-ChattingRandom128B1H4Mode.cmd from the extracted root.
3. Results will be written under Out\bench.

Included:
- Out\ChattingServer.exe
- Out\ChattingDummyClient.exe
- Config\Server\ChattingServer.yaml
- Config\Client\ChattingDummy.yaml
- scripts\bench runner files
- 4-mode Random 128B 1H manifest package
